
const express = require('express');
const multer = require('multer');
const nodemailer = require('nodemailer');
const path = require('path');
const cors = require('cors');
require('dotenv').config();

const app = express();
app.use(cors());
app.use(express.static('public'));

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, 'uploads/'),
  filename: (req, file, cb) => cb(null, Date.now() + '-' + file.originalname)
});
const upload = multer({ storage });

const transporter = nodemailer.createTransport({
  host: 'smtp.zoho.com',
  port: 465,
  secure: true,
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS
  }
});

app.post('/send-email', upload.single('logo'), (req, res) => {
  const { businessName, industry, services, dueDate, email, phone } = req.body;
  const logoPath = req.file?.path;

  const htmlContent = `
    <!DOCTYPE html>
    <html>
      <head>
        <style>
          body { font-family: Arial, sans-serif; background: #f9fafb; padding: 20px; }
          .container { max-width: 600px; margin: auto; background: white; padding: 30px; border-radius: 12px; box-shadow: 0 5px 15px rgba(0,0,0,0.05); }
          .header { text-align: center; color: #4f46e5; font-size: 24px; margin-bottom: 10px; }
          .subheader { text-align: center; font-size: 16px; color: #6b7280; margin-bottom: 30px; }
          .content p { margin: 10px 0; }
          .highlight { font-weight: bold; color: #111827; }
          .footer { margin-top: 30px; font-size: 12px; color: #9ca3af; text-align: center; }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">VisualVibe Studio</div>
          <div class="subheader">Receipt for Your Order</div>
          <div class="content">
            <p><span class="highlight">Business Name:</span> ${businessName}</p>
            <p><span class="highlight">Industry:</span> ${industry}</p>
            <p><span class="highlight">Services:</span> ${services}</p>
            <p><span class="highlight">Due Date:</span> ${dueDate}</p>
            <p><span class="highlight">Phone:</span> ${phone}</p>
            <p><span class="highlight">Email:</span> ${email}</p>
            <hr />
            <p><strong>Note:</strong> This receipt confirms you have paid 50% upfront. The remaining 50% is due after approval of final designs.</p>
          </div>
          <div class="footer">
            VisualVibe Studio &copy; 2025 — Branding that resonates
          </div>
        </div>
      </body>
    </html>
  `;

  const mailOptions = {
    from: \`VisualVibe Studio <\${process.env.EMAIL_USER}>\`,
    to: \`\${email}, \${process.env.OWNER_EMAIL}\`,
    subject: 'VisualVibe Studio - Order Receipt',
    html: htmlContent,
    attachments: logoPath ? [{ filename: req.file.originalname, path: logoPath }] : []
  };

  transporter.sendMail(mailOptions, (error, info) => {
    if (error) {
      console.error('Error sending email:', error);
      return res.status(500).send('Error sending email');
    }
    res.status(200).send('Email sent successfully');
  });
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(\`Server running at http://localhost:\${PORT}\`);
});
